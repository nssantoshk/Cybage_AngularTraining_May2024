import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CybComponentComponent } from './cyb-component.component';

describe('CybComponentComponent', () => {
  let component: CybComponentComponent;
  let fixture: ComponentFixture<CybComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CybComponentComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CybComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
