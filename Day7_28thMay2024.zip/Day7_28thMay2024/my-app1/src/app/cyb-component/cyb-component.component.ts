import { Component, Input} from '@angular/core';

@Component({
  selector: 'app-cyb-component',
  templateUrl: './cyb-component.component.html',
  styleUrl: './cyb-component.component.css'
})
export class CybComponentComponent {
  @Input() pname: string="";
  // @Input() page: number=0;
  @Input() pgender: string="";
}
