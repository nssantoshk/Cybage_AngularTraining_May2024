export interface weather{
    name: string,
    username: string,
    email: string
}