import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { weather } from './weather';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  ename: string;
  age: number;
  gender: string;
  salary: number;
  dob: Date;
  percentageIncrease: number;
  myobj:object={
    "name": "Jojo",
    "age": 23
  }
  weatherData:any[]=[];
  myapptitle:string;
  constructor(private httpClientObject:HttpClient){
    this.myapptitle="working with angular";
    this.age=0;
    this.ename="Popat Lal";
    this.gender="";
    this.salary=144200;
    this.dob=new Date(2004, 6, 12, 10, 15);
    this.percentageIncrease=33;
    this.httpClientObject.get("https://jsonplaceholder.typicode.com/users").
    subscribe(element=>{
      this.weatherData.push(element);
    });
  }

  showWeatherData():void{
    console.log(this.weatherData);
  }
}
