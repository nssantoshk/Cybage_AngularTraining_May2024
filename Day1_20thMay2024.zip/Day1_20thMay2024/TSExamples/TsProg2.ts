function DisplayData(ename:string):string{
    return "Name passed by you is : " + ename;
}

// var ename:string="Popat Lal";
// DisplayData(ename);