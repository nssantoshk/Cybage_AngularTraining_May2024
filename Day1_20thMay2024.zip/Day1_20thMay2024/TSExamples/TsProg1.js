var ename = "Jojo";
console.log("Value of variable ename is : " + ename);
