var Person = /** @class */ (function () {
    function Person(name, ag, ct) {
        this.age = ag;
        this.city = ct;
        this.ename = name;
    }
    Person.prototype.showPersonDetails = function () {
        var personInfo = "Name : " + this.ename +
            "Age : " + this.age +
            "City Name : " + this.city;
        return personInfo;
    };
    return Person;
}());
var p1 = new Person("Jojo", 23, "Delhi");
console.log(p1.showPersonDetails());
var people = [];
people[0] = new Person("Popat Lal", 25, "Sonipat");
people[1] = new Person("Santa Singh", 28, "Jallandhar");
people[2] = p1;
people.forEach(function (pElement) {
    console.table(pElement);
});
