class Demo{
    sayHello():string{
        return "Hello from the Demo class";
    }
}





