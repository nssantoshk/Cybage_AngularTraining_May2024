var ename: string="Jojo";

console.log("Value of variable ename is : " + ename);