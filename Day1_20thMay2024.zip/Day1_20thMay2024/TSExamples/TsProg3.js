var Demo = /** @class */ (function () {
    function Demo() {
    }
    Demo.prototype.sayHello = function () {
        return "Hello from the Demo class";
    };
    return Demo;
}());
