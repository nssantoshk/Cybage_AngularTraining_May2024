import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CybageDemoComp1Component } from './cybage-demo-comp1/cybage-demo-comp1.component';

@NgModule({
  declarations: [
    AppComponent,
    CybageDemoComp1Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
