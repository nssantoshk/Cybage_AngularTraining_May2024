import { CybagePerson } from './cybage-person';

describe('CybagePerson', () => {
  it('should create an instance', () => {
    expect(new CybagePerson()).toBeTruthy();
  });
});
