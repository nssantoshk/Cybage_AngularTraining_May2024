import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CybageDemoComp1Component } from './cybage-demo-comp1.component';

describe('CybageDemoComp1Component', () => {
  let component: CybageDemoComp1Component;
  let fixture: ComponentFixture<CybageDemoComp1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CybageDemoComp1Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CybageDemoComp1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
