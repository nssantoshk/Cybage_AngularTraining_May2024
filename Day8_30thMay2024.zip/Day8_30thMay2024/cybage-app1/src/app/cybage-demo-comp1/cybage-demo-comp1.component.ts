import { Component } from '@angular/core';
import { CybageDemoServiceService } from '../cybage-demo-service.service';
import { CybagePerson } from '../cybage-person';

@Component({
  selector: 'app-cybage-demo-comp1',
  templateUrl: './cybage-demo-comp1.component.html',
  styleUrl: './cybage-demo-comp1.component.css'
})

export class CybageDemoComp1Component {
  componentContent:string;
  mypeople:CybagePerson[]=[];
  constructor(private serviceObject:CybageDemoServiceService){
    this.componentContent=this.serviceObject.greetMyCustomer();
    this.mypeople=this.serviceObject.populatePeopleData();
  }

}
