import { TestBed } from '@angular/core/testing';

import { CybageDemoServiceService } from './cybage-demo-service.service';

describe('CybageDemoServiceService', () => {
  let service: CybageDemoServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CybageDemoServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
