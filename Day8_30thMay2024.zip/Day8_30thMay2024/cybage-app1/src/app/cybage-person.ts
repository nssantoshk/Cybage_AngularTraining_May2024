export class CybagePerson {
    ename:string;
    eage:number;
    ecity:string;
    constructor(name:string,
        age: number, city: string){
            this.eage=age;
            this.ecity=city;
            this.ename=name;
        }
}
