import { CybagePerson } from "./cybage-person";

export const allcybagepeoples:CybagePerson[]=[
    new CybagePerson("Jojo", 23, "Delhi"),
    new CybagePerson("Popat Lal", 25, "Sonipat"),
    new CybagePerson("Santa Singh", 28, "Jallandhar"),
    new CybagePerson("Banta Singh", 29, "Amritsar"),
    new CybagePerson("John", 33, "Delhi")
];