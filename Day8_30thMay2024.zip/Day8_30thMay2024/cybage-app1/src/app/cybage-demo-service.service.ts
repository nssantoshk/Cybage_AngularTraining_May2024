import { Injectable } from '@angular/core';
import { CybagePerson } from './cybage-person';
import { allcybagepeoples } from './allcybagepeople';

@Injectable({
  providedIn: 'root'
})
export class CybageDemoServiceService {

  constructor() {
   }
  
   greetMyCustomer():string{
    return "Hello Customer, how are you?";
   }

   populatePeopleData():CybagePerson[]{
    return allcybagepeoples;
   }
}
