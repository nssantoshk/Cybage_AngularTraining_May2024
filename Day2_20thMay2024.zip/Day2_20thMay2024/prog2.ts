class Emp{
    /// Define required fields to collect name, designation and salary
    /// Define required methods to modify the data and render the data back to the user
    show():string{

    }
}

class Company{
    empItem:Emp;    /// Currently this indicates that company has only one employee
    employees:Emp[]=[];
    companyname: string;
    companyaddress: string;
    constructor(){
        this.empItem=new Emp();
        /// Complete the constructor definition to accept company name and address
    }
    /// Defined required methods to render the data of company and employee data back to the user
    registerEmployee(empElement:Emp):void{
        this.employees.push(empElement);
    }

    showEmployeeDetails():void{
        this.employees.forEach(function(empObject){
            console.log(empObject.show());
        });
    }

}