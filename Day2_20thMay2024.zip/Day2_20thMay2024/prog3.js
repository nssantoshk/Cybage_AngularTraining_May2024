"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function helloWorld() {
    console.log("Hello, world!");
}
exports.default = helloWorld;
