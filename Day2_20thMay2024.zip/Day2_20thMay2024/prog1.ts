class Person{
    pname: string;
    page:  number;
    constructor(nm: string, ag: number){
        this.page=ag;
        this.pname=nm;
        console.log("Hello all, this is from the Person class");
    }
}

class Manager extends Person{
    desig: string;
    salary: number;
    constructor(
        ename: string, eage: number,
        designation: string, sal: number
    ){
        super(ename, eage);
        this.desig=designation;
        this.salary=sal;
        console.log("Welcome to the Manager class");
    }

    showEmpDetails():string{
        //  write required logic to return employee name,
        //  employee age, designation and salary
    }
}

