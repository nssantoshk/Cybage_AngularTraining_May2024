import helloWorld from "./prog3.js";

helloWorld();