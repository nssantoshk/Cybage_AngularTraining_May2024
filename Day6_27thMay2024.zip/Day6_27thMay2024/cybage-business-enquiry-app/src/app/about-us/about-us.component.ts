import { Component } from '@angular/core';
import { Emp } from '../emp';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrl: './about-us.component.css'
})
export class AboutUsComponent {
  componentTitle:string;
  employees:Emp[]=[];
  empItem:Emp;
  transactionstatus:string;

  constructor(){
    this.componentTitle="About Us - Know More About Us";
    this.empItem={
      empdesig:"",
      empname:"",
      empsalary:0
    };
    this.transactionstatus="";
  }

  addDataToList():void{
    this.employees.push(this.empItem);
    alert("Data Added and Saved to Temporary List");
    console.log("Total number of elements added : " + 
      this.employees.length);
      console.log(this.employees);
    this.empItem={
      empdesig:"",
      empname:"",
      empsalary:0
    };
  }

  saveCollectedData():void{
    localStorage.setItem("CybageEmployees", 
      JSON.stringify(this.employees));
    this.employees=[];
    this.transactionstatus="Data Saved Successfully";
    
  }

  clearFormFields():void{
    this.transactionstatus="";
  }
  



}
