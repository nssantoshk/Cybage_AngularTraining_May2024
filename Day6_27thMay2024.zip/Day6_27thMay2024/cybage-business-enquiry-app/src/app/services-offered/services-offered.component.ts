import { Component } from '@angular/core';

@Component({
  selector: 'app-services-offered',
  templateUrl: './services-offered.component.html',
  styleUrl: './services-offered.component.css'
})
export class ServicesOfferedComponent {

}
