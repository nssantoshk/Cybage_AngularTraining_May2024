export interface Emp {
    empname: string;
    empdesig: string;
    empsalary: number;
}
