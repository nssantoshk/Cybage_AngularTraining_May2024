function show():string{
    return "Hello All and welcome to the TS training session";
}

function displayMyNames():string[]{
    var allNames:string[]=[
        "Jojo", "Popat Lal",
        "Santa Singh", "Banta Singh",
        "Sohan Lal"
    ];

    return allNames;
}

function calculateProduct(num1: number,
    num2: number):number{
        return num1 * num2;
    }

    