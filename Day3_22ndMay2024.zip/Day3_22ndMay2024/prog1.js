function show() {
    return "Hello All and welcome to the TS training session";
}
function displayMyNames() {
    var allNames = [
        "Jojo", "Popat Lal",
        "Santa Singh", "Banta Singh",
        "Sohan Lal"
    ];
    return allNames;
}
