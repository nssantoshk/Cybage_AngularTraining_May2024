import { CybageDemo } from './cybage-demo';

describe('CybageDemo', () => {
  it('should create an instance', () => {
    expect(new CybageDemo()).toBeTruthy();
  });
});
