import { Component } from '@angular/core';
import { CybageDemo } from './cybage-demo';

@Component({
  selector: 'cybage-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent {
  mainAppTitle: string;

  allNames:string[]=[
    "Jojo", "Popat Lal", "Santa Singh",
    "Banta Singh", "Sohan Lal", "Peter",
    "Kk"
  ];

  demoObj:CybageDemo;

  constructor(){
    this.mainAppTitle="";
    this.demoObj={
      personage: 0,
      personcity: "",
      personname: ""
    };
  }

  printSomething():void{
    this.mainAppTitle="We are learning on how to work with Angular";
  }

  hideHeaderContent():void{
    this.mainAppTitle="";
  }

  showPeopleContent():void{
    this.demoObj={
      personage: 23,
      personcity: "Delhi",
      personname: "Jojo"
    };
  }

}
