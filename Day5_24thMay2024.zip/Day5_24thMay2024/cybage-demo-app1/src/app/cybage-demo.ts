export interface CybageDemo {
    personname: string;
    personage:number;
    personcity: string;
}
